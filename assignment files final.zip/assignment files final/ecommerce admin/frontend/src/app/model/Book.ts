export class Book {
    id: number;
    name: string;
    author: string;
    price: number;
    picByte: string;
    retrievedImage: string;
}