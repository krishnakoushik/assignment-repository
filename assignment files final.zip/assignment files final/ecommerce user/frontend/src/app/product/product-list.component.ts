import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  dataone:any[];
  constructor(private userService:UserService,
    private productService:ProductserviceService,private router:Router) { }

  ngOnInit() {
    return this.userService.getdata().subscribe((data:any)=>this.dataone=data);
  }
  addToCart(prod){
    console.log(".ts angular")
    console.log(prod.proId);
    this.router.navigate(["/cart"])
    //return this.productService.addToCart(prod.proId)
    
  }


}
