import { Injectable } from '@angular/core';
import { HttpClient } from '../../node_modules/@angular/common/http';
import { Router } from '../../node_modules/@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  constructor(private httpClient:HttpClient,private router:Router) { }
  getProductsByCategory(name:String){
    console.log(name)
    return this.httpClient.get("http://localhost:9632/product/getByCategory/"+name);
  }
  search(){
    this.router.navigate(['/search']);
  }
  searchByName(search:string){
    return this.httpClient.get("http://localhost:9632/product/getByCategoryandPrice?search="+search);
    }
    getCartProducts(){
      //this.httpClient.get("http://localhost:9632/cartlist/getAll");
      //this.httpClient.post("http://localhost:9632/cartlist/addToCart",);
    }
    checkForgotPassword(id:number,answer:String){
      return this.httpClient.get("")
    }
    addToCart(id:String){
     /*  let input={
        
        "proName":prod.proName,
        "proDesc":prod.proDesc,
        "proPrice":prod.proPrice,
        "proCategory":prod.proCategory,
        "imageUrl":prod.imageUrl
      } */
      //console.log("in service"+id)

      return this.httpClient.get("http://localhost:9632/cartlist/cart?productId="+id);
    }
}