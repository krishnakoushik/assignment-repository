import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 
  model:any={};
  result:number;

  model1:any={};
  result1:number;
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
  }
  addAdmin():any{
    console.log(this.model1);
    this.userService.addAdmin(this.model1).subscribe((data:number)=>{this.result1=data;
    console.log(this.result1);
    if(this.result1==1){
      alert("Registration Successfull")
      this.router.navigate(['/login']);
    }
    else{
      alert("Not a vaild user")
    }
  });
}
  addUser():any{
    console.log(this.model);
    this.userService.addUser(this.model).subscribe((data:number)=>{this.result=data;
    console.log(this.result);
    if(this.result==1){
      alert("Registration Successfull")
      this.router.navigate(['/login']);
    }
    else if(this.result==2){
      this.userService.addAdmin(this.model).subscribe((data:number)=>{this.result=data;
        console.log(this.result);})
        alert("Registration Successfull")
      this.router.navigate(['/login']);
    }
    else{
      alert("User Already Exist")
    }
  });
} 
}  