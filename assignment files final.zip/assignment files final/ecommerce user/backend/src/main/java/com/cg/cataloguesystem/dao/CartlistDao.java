package com.cg.cataloguesystem.dao;

import java.util.List;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;

public interface CartlistDao {
	CartDetails createCartDetails(CartDetails cartlist);
	List<CartDetails> getAllCart();
	 CartDetails getByIdInCartList(int id);
	 void addToCart1(String id);
	 boolean addToCart(String productId);
}
