package com.cg.cataloguesystem.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;

@Repository
public class WishlistDaoImpl implements WishlistDao{
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public WishlistDetails createWishlist(WishlistDetails wishlist) {
		// TODO Auto-generated method stub
		return mongotemplate.insert(wishlist);
	}

	@Override
	public List<WishlistDetails> getAllWishlist() {
		
		return mongotemplate.findAll(WishlistDetails.class);
	}

	@Override
	public WishlistDetails getByIdInWhishList(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id,WishlistDetails.class);
	}


	
	

	}


