package com.cg.cataloguesystem.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;
import com.cg.cataloguesystem.dao.WishlistDao;
@Service
public class WishlistServiceImpl implements WishlistService {
	@Autowired
	WishlistDao wishdao;

	@Override
	public WishlistDetails createWishlist(WishlistDetails wishlist) {
		// TODO Auto-generated method stub
		return wishdao.createWishlist(wishlist);
	}

	@Override
	public List<WishlistDetails> getAllWishlist() {
		// TODO Auto-generated method stub
		return wishdao.getAllWishlist();
	}

	@Override
	public WishlistDetails getByIdInWhishList(int id) {
		// TODO Auto-generated method stub
		return wishdao.getByIdInWhishList(id);
	}
	
	
}
