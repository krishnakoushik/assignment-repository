package com.cg.cataloguesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@ComponentScan("com.cg.cataloguesystem")
@SpringBootApplication
public class CatalogueSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogueSystemApplication.class, args);
		System.out.println("hello");
	}

}
