package com.cg.cataloguesystem.dao;

import java.util.List;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;

public interface UserlistDao {
	Integer createIncomeTax(UserDetails userlist);
	List<UserDetails> getAllUser();
	UserDetails getByUserId(int id);
	List<UserDetails> getByName(String name);
	Integer validateByMailPswd(String mailId,String pswd);
}
