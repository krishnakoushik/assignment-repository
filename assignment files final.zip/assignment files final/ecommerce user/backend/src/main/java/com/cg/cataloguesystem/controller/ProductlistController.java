package com.cg.cataloguesystem.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.service.ProductlistService;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins="http://localhost:4200")
public class ProductlistController {
	@Autowired
	ProductlistService productservice;
	List<ProductDetails> productsList=null;
	
	@PostMapping("/create")
	public ProductDetails createProduct(@RequestBody ProductDetails productdetails) {
		return productservice.createProductDetails(productdetails);
		
	}
	@GetMapping("/getall")
	public List<ProductDetails> getProduct(){
		return productservice.getAllProduct();
		
	}
	@GetMapping("/getByProductId")
		public ProductDetails getByProductId(@RequestParam("id") int id)
		{
		return productservice.getByProductId(id);
		}

	@GetMapping("/getByProductName")
	public ProductDetails getByName(@RequestParam("name") String name) {
		return productservice.getByName(name);
	}
	@GetMapping("/getByProudctPrice")
	public List<ProductDetails> getByProductPrice(@RequestParam("price") String price) {
		return productservice.getByProductPrice(price);
	}
	@GetMapping("/getByCategory/{categoryName}")
	public List<ProductDetails> getByCategory(@PathVariable("categoryName") String categoryName) {
		System.out.println(categoryName);
		return productservice.getByProductCategory(categoryName);
	}

	@PostMapping("/upload")
	public ResponseEntity<List<ProductDetails>> saveProduct(@RequestParam("file") MultipartFile file1) throws IOException{
		String line,name="C:\\Users\\srinadim\\Desktop\\"+file1.getOriginalFilename();
		FileReader fr=new FileReader(name);
		BufferedReader br=new BufferedReader(fr);
		ProductDetails product1=new ProductDetails();
		while((line=br.readLine())!=null) { 
			ProductDetails product=new ProductDetails();
			String []data=line.split(",");
			product.setProName(data[0]);
			product.setProPrice(data[1]);
			product.setProDesc(data[2]);
			product.setProCategory(data[3]);
			product.setImageUrl(data[4]);
			product.setAvailability(data[5]);
			product.setProId(data[6]);
			
			productservice.createProductDetails(product);
		}
	
	if(product1!=null) {
	    return new ResponseEntity(productsList,HttpStatus.OK);
	    }
	return new ResponseEntity(null,HttpStatus.NOT_FOUND);
 }

@GetMapping("/getProducts")
public ResponseEntity<List<ProductDetails>> getProducts()
{
	System.out.println("hello");
	productsList=productservice.getAllProduct();
  //  System.out.println(productsList);
	if(productsList==null) {
		return new ResponseEntity("No data found",HttpStatus.NOT_FOUND);
	}
    return new ResponseEntity<List<ProductDetails>>(productsList,HttpStatus.OK);
}
@GetMapping("/getByCategoryandPrice")
public List<ProductDetails> search(@RequestParam("search") String search) {
	return productservice.searchByCategoryandPrice(search);
}
}
